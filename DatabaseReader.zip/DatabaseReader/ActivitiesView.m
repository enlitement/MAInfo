//
//  ActivitiesView.m
//  DatabaseReader
//
//  Created by Taveras, Helson on 3/4/14.
//  Copyright (c) 2014 Taveras, Helson. All rights reserved.
//

#import "ActivitiesView.h"
#import "Activity.h"

@interface ActivitiesView ()

@end

@implementation ActivitiesView
//http://www.appcoda.com/fetch-parse-json-ios-programming-tutorial/ 
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    Activity *activity = [Activity alloc];
    [activity init];
    
    // URL of the activities
    NSString *url = @"http://www.saa.ma1geek.org/getActivities.php";
    // Any errors in the url
    NSError *error;
    
    NSURLResponse *response = nil;
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString: url]];
    [request setHTTPMethod:@"GET"];
    // Send the request for the data
    NSData *JSONData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSDictionary* json = [NSJSONSerialization
                          JSONObjectWithData:JSONData
                          options:kNilOptions
                          error:&error];
    
    NSArray* latestLoans = [json objectForKey:@"Activities"];
    
    [activity setDescription:latestLoans.description];
    
    NSLog(@"Activities: %@", [activity description]);
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
