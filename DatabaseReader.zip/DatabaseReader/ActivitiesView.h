//
//  ActivitiesView.h
//  DatabaseReader
//
//  Created by Taveras, Helson on 3/4/14.
//  Copyright (c) 2014 Taveras, Helson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivitiesView : UIViewController

@end
