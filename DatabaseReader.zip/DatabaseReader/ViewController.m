//
//  ViewController.m
//  DatabaseReader
//
//  Created by Taveras, Helson on 3/4/14.
//  Copyright (c) 2014 Taveras, Helson. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize label, objectReturnedFromJSON, table;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onButtonPress:(id)sender {
    jsonArray = [[NSMutableArray alloc] init];
    table = [[UITableView alloc] init];
    
    // URL of the activities
    NSString *url = @"http://www.saa.ma1geek.org/getActivities.php";
    // Any errors in the url
    NSError *error;

    NSURLResponse *response = nil;
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString: url]];
    [request setHTTPMethod:@"GET"];
    // Send the request for the data
    NSData *JSONData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSDictionary *jsonDic = [NSJSONSerialization
                             JSONObjectWithData:JSONData
                             options:0
                             error:&error];
    
    NSDictionary *entreeDic = [jsonDic objectForKey:@"Activities"];
    
    for(NSDictionary *activities in entreeDic){
        NSString *holdString = [NSString stringWithFormat:@"%@", [activities objectForKey:@"eventName"]];
        NSLog(@"Activity Name: %@", holdString);
        [jsonArray addObject:holdString];
        // This should add the text to the cell. But it doesn't. 
        static NSString *cellIdentifier = @"Id";
        UITableViewCell *cell = [table dequeueReusableCellWithIdentifier:cellIdentifier];
        if(cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.text = holdString;

    }
     NSLog(@"jsonArray: %@", jsonArray);
    
    [[self table] insertRowsAtIndexPaths:(NSArray *)jsonArray withRowAnimation:UITableViewRowAnimationNone];
     NSLog(@"inserted.");
}
@end